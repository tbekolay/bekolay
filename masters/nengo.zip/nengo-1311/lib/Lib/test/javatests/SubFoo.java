package javatests;

public class SubFoo extends Foo {}
