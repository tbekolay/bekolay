import math
import random
import numpy
import pylab
from matplotlib import rc
rc('text',usetex=True)
rc('font',family='serif')

directory='./'

try:
    use_sub
    directory='data/theta0.33/pulse_delay_15hz/'
except NameError:
    use_sub = False

##################
#Functions called#
##################
def sample(data):
    for _ in data:
        yield random.choice(data)
def bootstrapci(data,func,n,p):
    index = int(n*(1-p)/2)
    r = [func(list(sample(data))) for _ in range(n)]
    r.sort()
    return r[index],r[-index]
def read_file(filename):
    z_before = None
    z_after = None
    z_ratio = None
    
    try:
        csv_f = open(filename)
        rows = csv_f.readlines()
    except:
        raise Exception("Error reading %s" % filename)

    z_before = []
    z_after = []
    z_ratio = []
    
    for row in rows:
        s_row = row.split(', ')
        z_before.append(float(s_row[0]))
        z_after.append(float(s_row[1]))
        z_ratio.append(float(s_row[2]))
    csv_f.close()
    
    return (z_before,z_after,z_ratio)

###############
# Sim results #
###############
files = [directory+fn for fn in [
'pulse_delay--0.03-2011-08-06_23-05-24.csv',
'pulse_delay--0.029-2011-08-06_23-09-38.csv',
'pulse_delay--0.028-2011-08-06_23-13-52.csv',
'pulse_delay--0.027-2011-08-06_23-18-16.csv',
'pulse_delay--0.026000000000000002-2011-08-06_23-22-41.csv',
'pulse_delay--0.025-2011-08-06_23-26-58.csv',
'pulse_delay--0.024-2011-08-06_23-31-19.csv',
'pulse_delay--0.023-2011-08-06_23-35-25.csv',
'pulse_delay--0.022-2011-08-06_23-39-32.csv',
'pulse_delay--0.021-2011-08-06_23-43-44.csv',
'pulse_delay--0.02-2011-08-06_23-47-59.csv',
'pulse_delay--0.019-2011-08-06_23-52-01.csv',
'pulse_delay--0.018000000000000002-2011-08-06_23-56-24.csv',
'pulse_delay--0.017-2011-08-07_00-00-43.csv',
'pulse_delay--0.016-2011-08-07_00-04-50.csv',
'pulse_delay--0.015-2011-08-07_00-09-11.csv',
'pulse_delay--0.014-2011-08-07_00-13-30.csv',
'pulse_delay--0.013000000000000001-2011-08-07_00-17-47.csv',
'pulse_delay--0.012-2011-08-07_00-21-50.csv',
'pulse_delay--0.011-2011-08-07_00-26-06.csv',
'pulse_delay--0.01-2011-08-07_00-30-08.csv',
'pulse_delay--0.009000000000000001-2011-08-07_00-34-05.csv',
'pulse_delay--0.008-2011-08-07_00-38-21.csv',
'pulse_delay--0.007-2011-08-07_00-42-26.csv',
'pulse_delay--0.006-2011-08-07_00-46-34.csv',
'pulse_delay--0.005-2011-08-07_00-50-41.csv',
'pulse_delay--0.004-2011-08-07_00-54-54.csv',
'pulse_delay--0.003-2011-08-07_00-59-09.csv',
'pulse_delay--0.002-2011-08-07_01-03-29.csv',
'pulse_delay--0.001-2011-08-07_01-08-02.csv',
'pulse_delay-0.0-2011-08-07_01-12-18.csv',
'pulse_delay-0.001-2011-08-07_01-16-36.csv',
'pulse_delay-0.002-2011-08-07_01-20-48.csv',
'pulse_delay-0.003-2011-08-07_01-25-02.csv',
'pulse_delay-0.004-2011-08-07_01-29-18.csv',
'pulse_delay-0.005-2011-08-07_01-33-14.csv',
'pulse_delay-0.006-2011-08-07_01-37-23.csv',
'pulse_delay-0.007-2011-08-07_01-41-37.csv',
'pulse_delay-0.008-2011-08-07_01-45-55.csv',
'pulse_delay-0.009000000000000001-2011-08-07_01-49-58.csv',
'pulse_delay-0.01-2011-08-07_01-54-06.csv',
'pulse_delay-0.011-2011-08-07_01-58-22.csv',
'pulse_delay-0.012-2011-08-07_02-02-29.csv',
'pulse_delay-0.013000000000000001-2011-08-07_02-06-34.csv',
'pulse_delay-0.014-2011-08-07_02-10-55.csv',
'pulse_delay-0.015-2011-08-07_02-15-18.csv',
'pulse_delay-0.016-2011-08-07_02-19-28.csv',
'pulse_delay-0.017-2011-08-07_02-23-36.csv',
'pulse_delay-0.018000000000000002-2011-08-07_02-27-52.csv',
'pulse_delay-0.019-2011-08-07_02-32-07.csv',
]]
sim_x = [n*0.001 for n in range(-30,20,1)]

mean = []; cil = []; cih = []
for f in files:
    b,a,r = read_file(f)
    mean.append(numpy.mean(r))
    l,h = bootstrapci(r,numpy.mean,1000,0.95)
    cil.append(l)
    cih.append(h)

#################
# Plotting code #
#################
c = '0.25'
l = r"$\theta=0.33$"
if not use_sub:
    pylab.figure(1,figsize=(8,4))
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c)
    pylab.axhline(linestyle='--',linewidth=1,color='k')
    pylab.axis([-0.03,0.02,-0.4,0.6])
else:
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c,label=l)

if not use_sub:
    pylab.show()

