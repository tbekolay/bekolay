import math
import random
import numpy
import pylab
from matplotlib import rc
rc('text',usetex=True)
rc('font',family='serif')

directory='./'

try:
    use_sub
    directory='data/theta0.33/pulse_rate_post_pre/'
except NameError:
    use_sub = False

##################
#Functions called#
##################
def sample(data):
    for _ in data:
        yield random.choice(data)
def bootstrapci(data,func,n,p):
    index = int(n*(1-p)/2)
    r = [func(list(sample(data))) for _ in range(n)]
    r.sort()
    return r[index],r[-index]
def read_file(filename):
    z_before = None
    z_after = None
    z_ratio = None
    
    try:
        csv_f = open(filename)
        rows = csv_f.readlines()
    except:
        raise Exception("Error reading %s" % filename)

    z_before = []
    z_after = []
    z_ratio = []
    
    for row in rows:
        s_row = row.split(', ')
        z_before.append(float(s_row[0]))
        z_after.append(float(s_row[1]))
        z_ratio.append(float(s_row[2]))
    csv_f.close()
    
    return (z_before,z_after,z_ratio)

###############
# Sim results #
###############
files = [directory+fn for fn in [
'pulse_rate-0.1-2011-08-06_21-25-17.csv',
'pulse_rate-1.0-2011-08-06_21-29-39.csv',
'pulse_rate-5.0-2011-08-06_21-33-58.csv',
'pulse_rate-10.0-2011-08-06_21-38-12.csv',
'pulse_rate-20.0-2011-08-06_21-42-30.csv',
'pulse_rate-50.0-2011-08-06_21-46-42.csv',
'pulse_rate-100.0-2011-08-06_21-50-57.csv',
]]
sim_x = [
0.1,
1.0,
5.0,
10.0,
20.0,
50.0,
100.0,
]

mean = []; cil = []; cih = []
for f in files:
    b,a,r = read_file(f)
    mean.append(numpy.mean(r))
    l,h = bootstrapci(r,numpy.mean,1000,0.95)
    cil.append(l)
    cih.append(h)

#################
# Plotting code #
#################
c = '0.25'
l = r"$\theta=0.33$"
if not use_sub:
    pylab.figure(1,figsize=(8,4))
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c)
    pylab.axhline(linestyle='--',linewidth=1,color='k')
    pylab.axis([-0.03,0.02,-0.4,0.6])
else:
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c,label=l)

if not use_sub:
    pylab.show()

