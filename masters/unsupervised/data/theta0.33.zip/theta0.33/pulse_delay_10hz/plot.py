import math
import random
import numpy
import pylab
from matplotlib import rc
rc('text',usetex=True)
rc('font',family='serif')

directory='./'

try:
    use_sub
    directory='data/theta0.33/pulse_delay_10hz/'
except NameError:
    use_sub = False

##################
#Functions called#
##################
def sample(data):
    for _ in data:
        yield random.choice(data)
def bootstrapci(data,func,n,p):
    index = int(n*(1-p)/2)
    r = [func(list(sample(data))) for _ in range(n)]
    r.sort()
    return r[index],r[-index]
def read_file(filename):
    z_before = None
    z_after = None
    z_ratio = None
    
    try:
        csv_f = open(filename)
        rows = csv_f.readlines()
    except:
        raise Exception("Error reading %s" % filename)

    z_before = []
    z_after = []
    z_ratio = []
    
    for row in rows:
        s_row = row.split(', ')
        z_before.append(float(s_row[0]))
        z_after.append(float(s_row[1]))
        z_ratio.append(float(s_row[2]))
    csv_f.close()
    
    return (z_before,z_after,z_ratio)

###############
# Sim results #
###############
files = [directory+fn for fn in [
'pulse_delay--0.03-2011-08-06_20-34-28.csv',
'pulse_delay--0.029-2011-08-06_20-36-16.csv',
'pulse_delay--0.028-2011-08-06_20-38-02.csv',
'pulse_delay--0.027-2011-08-06_20-39-51.csv',
'pulse_delay--0.026000000000000002-2011-08-06_20-41-42.csv',
'pulse_delay--0.025-2011-08-06_20-43-28.csv',
'pulse_delay--0.024-2011-08-06_20-45-21.csv',
'pulse_delay--0.023-2011-08-06_20-47-05.csv',
'pulse_delay--0.022-2011-08-06_20-48-55.csv',
'pulse_delay--0.021-2011-08-06_20-50-42.csv',
'pulse_delay--0.02-2011-08-06_20-52-29.csv',
'pulse_delay--0.019-2011-08-06_20-54-16.csv',
'pulse_delay--0.018000000000000002-2011-08-06_20-56-06.csv',
'pulse_delay--0.017-2011-08-06_20-57-55.csv',
'pulse_delay--0.016-2011-08-06_20-59-40.csv',
'pulse_delay--0.015-2011-08-06_21-01-27.csv',
'pulse_delay--0.014-2011-08-06_21-03-13.csv',
'pulse_delay--0.013000000000000001-2011-08-06_21-05-05.csv',
'pulse_delay--0.012-2011-08-06_21-06-53.csv',
'pulse_delay--0.011-2011-08-06_21-08-43.csv',
'pulse_delay--0.01-2011-08-06_21-10-29.csv',
'pulse_delay--0.009000000000000001-2011-08-06_21-12-18.csv',
'pulse_delay--0.008-2011-08-06_21-14-03.csv',
'pulse_delay--0.007-2011-08-06_21-15-48.csv',
'pulse_delay--0.006-2011-08-06_21-17-35.csv',
'pulse_delay--0.005-2011-08-06_21-19-18.csv',
'pulse_delay--0.004-2011-08-06_21-21-06.csv',
'pulse_delay--0.003-2011-08-06_21-22-52.csv',
'pulse_delay--0.002-2011-08-06_21-24-37.csv',
'pulse_delay--0.001-2011-08-06_21-26-24.csv',
'pulse_delay-0.0-2011-08-06_21-28-13.csv',
'pulse_delay-0.001-2011-08-06_21-30-01.csv',
'pulse_delay-0.002-2011-08-06_21-31-44.csv',
'pulse_delay-0.003-2011-08-06_21-33-29.csv',
'pulse_delay-0.004-2011-08-06_21-35-14.csv',
'pulse_delay-0.005-2011-08-06_21-37-01.csv',
'pulse_delay-0.006-2011-08-06_21-38-44.csv',
'pulse_delay-0.007-2011-08-06_21-40-35.csv',
'pulse_delay-0.008-2011-08-06_21-42-21.csv',
'pulse_delay-0.009000000000000001-2011-08-06_21-44-07.csv',
'pulse_delay-0.01-2011-08-06_21-45-49.csv',
'pulse_delay-0.011-2011-08-06_21-47-35.csv',
'pulse_delay-0.012-2011-08-06_21-49-24.csv',
'pulse_delay-0.013000000000000001-2011-08-06_21-51-10.csv',
'pulse_delay-0.014-2011-08-06_21-52-53.csv',
'pulse_delay-0.015-2011-08-06_21-54-42.csv',
'pulse_delay-0.016-2011-08-06_21-56-25.csv',
'pulse_delay-0.017-2011-08-06_21-58-07.csv',
'pulse_delay-0.018000000000000002-2011-08-06_21-59-57.csv',
'pulse_delay-0.019-2011-08-06_22-01-42.csv',
]]
sim_x = [n*0.001 for n in range(-30,20,1)]

mean = []; cil = []; cih = []
for f in files:
    b,a,r = read_file(f)
    mean.append(numpy.mean(r))
    l,h = bootstrapci(r,numpy.mean,1000,0.95)
    cil.append(l)
    cih.append(h)

#################
# Plotting code #
#################
c = '0.25'
l = r"$\theta=0.33$"
if not use_sub:
    pylab.figure(1,figsize=(8,4))
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c)
    pylab.axhline(linestyle='--',linewidth=1,color='k')
    pylab.axis([-0.03,0.02,-0.4,0.6])
else:
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c,label=l)

if not use_sub:
    pylab.show()

