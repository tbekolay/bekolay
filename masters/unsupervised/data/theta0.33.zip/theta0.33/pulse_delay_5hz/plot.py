import math
import random
import numpy
import pylab
from matplotlib import rc
rc('text',usetex=True)
rc('font',family='serif')

directory='./'

try:
    use_sub
    directory='data/theta0.33/pulse_delay_5hz/'
except NameError:
    use_sub = False

##################
#Functions called#
##################
def sample(data):
    for _ in data:
        yield random.choice(data)
def bootstrapci(data,func,n,p):
    index = int(n*(1-p)/2)
    r = [func(list(sample(data))) for _ in range(n)]
    r.sort()
    return r[index],r[-index]
def read_file(filename):
    z_before = None
    z_after = None
    z_ratio = None
    
    try:
        csv_f = open(filename)
        rows = csv_f.readlines()
    except:
        raise Exception("Error reading %s" % filename)

    z_before = []
    z_after = []
    z_ratio = []
    
    for row in rows:
        s_row = row.split(', ')
        z_before.append(float(s_row[0]))
        z_after.append(float(s_row[1]))
        z_ratio.append(float(s_row[2]))
    csv_f.close()
    
    return (z_before,z_after,z_ratio)

###############
# Sim results #
###############
files = [directory+fn for fn in [
'pulse_delay--0.03-2011-08-06_22-13-25.csv',
'pulse_delay--0.029-2011-08-06_22-15-07.csv',
'pulse_delay--0.028-2011-08-06_22-16-57.csv',
'pulse_delay--0.027-2011-08-06_22-18-47.csv',
'pulse_delay--0.026000000000000002-2011-08-06_22-20-34.csv',
'pulse_delay--0.025-2011-08-06_22-22-14.csv',
'pulse_delay--0.024-2011-08-06_22-24-06.csv',
'pulse_delay--0.023-2011-08-06_22-25-49.csv',
'pulse_delay--0.022-2011-08-06_22-27-39.csv',
'pulse_delay--0.021-2011-08-06_22-29-24.csv',
'pulse_delay--0.02-2011-08-06_22-31-04.csv',
'pulse_delay--0.019-2011-08-06_22-32-55.csv',
'pulse_delay--0.018000000000000002-2011-08-06_22-34-41.csv',
'pulse_delay--0.017-2011-08-06_22-36-30.csv',
'pulse_delay--0.016-2011-08-06_22-38-15.csv',
'pulse_delay--0.015-2011-08-06_22-40-02.csv',
'pulse_delay--0.014-2011-08-06_22-41-53.csv',
'pulse_delay--0.013000000000000001-2011-08-06_22-43-39.csv',
'pulse_delay--0.012-2011-08-06_22-45-24.csv',
'pulse_delay--0.011-2011-08-06_22-47-13.csv',
'pulse_delay--0.01-2011-08-06_22-49-00.csv',
'pulse_delay--0.009000000000000001-2011-08-06_22-50-50.csv',
'pulse_delay--0.008-2011-08-06_22-52-35.csv',
'pulse_delay--0.007-2011-08-06_22-54-18.csv',
'pulse_delay--0.006-2011-08-06_22-56-03.csv',
'pulse_delay--0.005-2011-08-06_22-57-50.csv',
'pulse_delay--0.004-2011-08-06_22-59-35.csv',
'pulse_delay--0.003-2011-08-06_23-01-23.csv',
'pulse_delay--0.002-2011-08-06_23-03-02.csv',
'pulse_delay--0.001-2011-08-06_23-04-47.csv',
'pulse_delay-0.0-2011-08-06_23-06-28.csv',
'pulse_delay-0.001-2011-08-06_23-08-14.csv',
'pulse_delay-0.002-2011-08-06_23-09-56.csv',
'pulse_delay-0.003-2011-08-06_23-11-41.csv',
'pulse_delay-0.004-2011-08-06_23-13-29.csv',
'pulse_delay-0.005-2011-08-06_23-15-14.csv',
'pulse_delay-0.006-2011-08-06_23-16-59.csv',
'pulse_delay-0.007-2011-08-06_23-18-48.csv',
'pulse_delay-0.008-2011-08-06_23-20-34.csv',
'pulse_delay-0.009000000000000001-2011-08-06_23-22-16.csv',
'pulse_delay-0.01-2011-08-06_23-24-05.csv',
'pulse_delay-0.011-2011-08-06_23-25-47.csv',
'pulse_delay-0.012-2011-08-06_23-27-29.csv',
'pulse_delay-0.013000000000000001-2011-08-06_23-29-16.csv',
'pulse_delay-0.014-2011-08-06_23-31-04.csv',
'pulse_delay-0.015-2011-08-06_23-32-50.csv',
'pulse_delay-0.016-2011-08-06_23-34-36.csv',
'pulse_delay-0.017-2011-08-06_23-36-19.csv',
'pulse_delay-0.018000000000000002-2011-08-06_23-38-03.csv',
'pulse_delay-0.019-2011-08-06_23-39-49.csv',
]]
sim_x = [n*0.001 for n in range(-30,20,1)]

mean = []; cil = []; cih = []
for f in files:
    b,a,r = read_file(f)
    mean.append(numpy.mean(r))
    l,h = bootstrapci(r,numpy.mean,1000,0.95)
    cil.append(l)
    cih.append(h)

#################
# Plotting code #
#################
c = '0.25'
l = r"$\theta=0.33$"
if not use_sub:
    pylab.figure(1,figsize=(8,4))
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c)
    pylab.axhline(linestyle='--',linewidth=1,color='k')
    pylab.axis([-0.03,0.02,-0.4,0.6])
else:
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c,label=l)

if not use_sub:
    pylab.show()

