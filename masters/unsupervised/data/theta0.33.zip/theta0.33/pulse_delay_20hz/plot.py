import math
import random
import numpy
import pylab
from matplotlib import rc
rc('text',usetex=True)
rc('font',family='serif')

directory='./'

try:
    use_sub
    directory='data/theta0.33/pulse_delay_20hz/'
except NameError:
    use_sub = False

##################
#Functions called#
##################
def sample(data):
    for _ in data:
        yield random.choice(data)
def bootstrapci(data,func,n,p):
    index = int(n*(1-p)/2)
    r = [func(list(sample(data))) for _ in range(n)]
    r.sort()
    return r[index],r[-index]
def read_file(filename):
    z_before = None
    z_after = None
    z_ratio = None
    
    try:
        csv_f = open(filename)
        rows = csv_f.readlines()
    except:
        raise Exception("Error reading %s" % filename)

    z_before = []
    z_after = []
    z_ratio = []
    
    for row in rows:
        s_row = row.split(', ')
        z_before.append(float(s_row[0]))
        z_after.append(float(s_row[1]))
        z_ratio.append(float(s_row[2]))
    csv_f.close()
    
    return (z_before,z_after,z_ratio)

###############
# Sim results #
###############
files = [directory+fn for fn in [
'pulse_delay--0.03-2011-08-06_20-14-23.csv',
'pulse_delay--0.029-2011-08-06_20-16-08.csv',
'pulse_delay--0.028-2011-08-06_20-17-53.csv',
'pulse_delay--0.027-2011-08-06_20-19-34.csv',
'pulse_delay--0.026000000000000002-2011-08-06_20-21-22.csv',
'pulse_delay--0.025-2011-08-06_20-23-13.csv',
'pulse_delay--0.024-2011-08-06_20-24-58.csv',
'pulse_delay--0.023-2011-08-06_20-26-48.csv',
'pulse_delay--0.022-2011-08-06_20-28-31.csv',
'pulse_delay--0.021-2011-08-06_20-30-15.csv',
'pulse_delay--0.02-2011-08-06_20-32-02.csv',
'pulse_delay--0.019-2011-08-06_20-33-44.csv',
'pulse_delay--0.018000000000000002-2011-08-06_20-35-31.csv',
'pulse_delay--0.017-2011-08-06_20-37-20.csv',
'pulse_delay--0.016-2011-08-06_20-39-07.csv',
'pulse_delay--0.015-2011-08-06_20-40-51.csv',
'pulse_delay--0.014-2011-08-06_20-42-33.csv',
'pulse_delay--0.013000000000000001-2011-08-06_20-44-18.csv',
'pulse_delay--0.012-2011-08-06_20-46-05.csv',
'pulse_delay--0.011-2011-08-06_20-47-52.csv',
'pulse_delay--0.01-2011-08-06_20-49-38.csv',
'pulse_delay--0.009000000000000001-2011-08-06_20-51-23.csv',
'pulse_delay--0.008-2011-08-06_20-53-03.csv',
'pulse_delay--0.007-2011-08-06_20-54-51.csv',
'pulse_delay--0.006-2011-08-06_20-56-42.csv',
'pulse_delay--0.005-2011-08-06_20-58-30.csv',
'pulse_delay--0.004-2011-08-06_21-00-18.csv',
'pulse_delay--0.003-2011-08-06_21-02-05.csv',
'pulse_delay--0.002-2011-08-06_21-03-53.csv',
'pulse_delay--0.001-2011-08-06_21-05-38.csv',
'pulse_delay-0.0-2011-08-06_21-07-23.csv',
'pulse_delay-0.001-2011-08-06_21-09-05.csv',
'pulse_delay-0.002-2011-08-06_21-10-49.csv',
'pulse_delay-0.003-2011-08-06_21-12-34.csv',
'pulse_delay-0.004-2011-08-06_21-14-24.csv',
'pulse_delay-0.005-2011-08-06_21-16-14.csv',
'pulse_delay-0.006-2011-08-06_21-18-04.csv',
'pulse_delay-0.007-2011-08-06_21-19-50.csv',
'pulse_delay-0.008-2011-08-06_21-21-39.csv',
'pulse_delay-0.009000000000000001-2011-08-06_21-23-21.csv',
'pulse_delay-0.01-2011-08-06_21-25-06.csv',
'pulse_delay-0.011-2011-08-06_21-26-48.csv',
'pulse_delay-0.012-2011-08-06_21-28-35.csv',
'pulse_delay-0.013000000000000001-2011-08-06_21-30-18.csv',
'pulse_delay-0.014-2011-08-06_21-32-01.csv',
'pulse_delay-0.015-2011-08-06_21-33-43.csv',
'pulse_delay-0.016-2011-08-06_21-35-27.csv',
'pulse_delay-0.017-2011-08-06_21-37-14.csv',
'pulse_delay-0.018000000000000002-2011-08-06_21-39-03.csv',
'pulse_delay-0.019-2011-08-06_21-40-50.csv',
]]
sim_x = [n*0.001 for n in range(-30,20,1)]

mean = []; cil = []; cih = []
for f in files:
    b,a,r = read_file(f)
    mean.append(numpy.mean(r))
    l,h = bootstrapci(r,numpy.mean,1000,0.95)
    cil.append(l)
    cih.append(h)

#################
# Plotting code #
#################
c = '0.25'
l = r"$\theta=0.33$"
if not use_sub:
    pylab.figure(1,figsize=(8,4))
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c)
    pylab.axhline(linestyle='--',linewidth=1,color='k')
    pylab.axis([-0.03,0.02,-0.4,0.6])
else:
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c,label=l)

if not use_sub:
    pylab.show()

