import math
import random
import numpy
import pylab
from matplotlib import rc
rc('text',usetex=True)
rc('font',family='serif')

directory='./'

try:
    use_sub
    directory='data/theta0.36/pulse_delay_20hz/'
except NameError:
    use_sub = False

##################
#Functions called#
##################
def sample(data):
    for _ in data:
        yield random.choice(data)
def bootstrapci(data,func,n,p):
    index = int(n*(1-p)/2)
    r = [func(list(sample(data))) for _ in range(n)]
    r.sort()
    return r[index],r[-index]
def read_file(filename):
    z_before = None
    z_after = None
    z_ratio = None
    
    try:
        csv_f = open(filename)
        rows = csv_f.readlines()
    except:
        raise Exception("Error reading %s" % filename)

    z_before = []
    z_after = []
    z_ratio = []
    
    for row in rows:
        s_row = row.split(', ')
        z_before.append(float(s_row[0]))
        z_after.append(float(s_row[1]))
        z_ratio.append(float(s_row[2]))
    csv_f.close()
    
    return (z_before,z_after,z_ratio)

###############
# Sim results #
###############
files = [directory+fn for fn in [
'pulse_delay-0.03.csv',
'pulse_delay-0.029.csv',
'pulse_delay-0.028.csv',
'pulse_delay-0.027.csv',
'pulse_delay-0.026000000000000002.csv',
'pulse_delay-0.025.csv',
'pulse_delay-0.024.csv',
'pulse_delay-0.023.csv',
'pulse_delay-0.022.csv',
'pulse_delay-0.021.csv',
'pulse_delay-0.02.csv',
'pulse_delay-0.019.csv',
'pulse_delay-0.018000000000000002.csv',
'pulse_delay-0.017.csv',
'pulse_delay-0.016.csv',
'pulse_delay-0.015.csv',
'pulse_delay-0.014.csv',
'pulse_delay-0.013000000000000001.csv',
'pulse_delay-0.012.csv',
'pulse_delay-0.011.csv',
'pulse_delay-0.01.csv',
'pulse_delay-0.009000000000000001.csv',
'pulse_delay-0.008.csv',
'pulse_delay-0.007.csv',
'pulse_delay-0.006.csv',
'pulse_delay-0.005.csv',
'pulse_delay-0.004.csv',
'pulse_delay-0.003.csv',
'pulse_delay-0.002.csv',
'pulse_delay-0.001.csv',
'pulse_delay+0.0.csv',
'pulse_delay+0.001.csv',
'pulse_delay+0.002.csv',
'pulse_delay+0.003.csv',
'pulse_delay+0.004.csv',
'pulse_delay+0.005.csv',
'pulse_delay+0.006.csv',
'pulse_delay+0.007.csv',
'pulse_delay+0.008.csv',
'pulse_delay+0.009000000000000001.csv',
'pulse_delay+0.01.csv',
'pulse_delay+0.011.csv',
'pulse_delay+0.012.csv',
'pulse_delay+0.013000000000000001.csv',
'pulse_delay+0.014.csv',
'pulse_delay+0.015.csv',
'pulse_delay+0.016.csv',
'pulse_delay+0.017.csv',
'pulse_delay+0.018000000000000002.csv',
'pulse_delay+0.019.csv',
'pulse_delay+0.02.csv',
]]
sim_x = [n*0.001 for n in range(-30,21,1)]

mean = []; cil = []; cih = []
for f in files:
    b,a,r = read_file(f)
    mean.append(numpy.mean(r))
    l,h = bootstrapci(r,numpy.mean,1000,0.95)
    cil.append(l)
    cih.append(h)

#################
# Plotting code #
#################
c = '0.5'
l = r"$\theta=0.36$"
if not use_sub:
    pylab.figure(1,figsize=(8,4))
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c)
    pylab.axhline(linestyle='--',linewidth=1,color='k')
    pylab.axis([-0.03,0.02,-0.4,0.6])
else:
    pylab.fill_between(sim_x,y1=cil,y2=cih,color=c,alpha=0.4)
    pylab.plot(sim_x,mean,linestyle='-',linewidth=2.0,color=c,label=l)

if not use_sub:
    pylab.show()

